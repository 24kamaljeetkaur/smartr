   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">

                	<p>Project Developed by Akanksha </p>
                	<p>Contect no. 7508832551</p>
                	<p>Email : akanksha@gmail.com</p>
                  <a> &copy; <?php echo date('Y');?> Online Library Management System</a>
                </div>

            </div>
        </div>
    </section>